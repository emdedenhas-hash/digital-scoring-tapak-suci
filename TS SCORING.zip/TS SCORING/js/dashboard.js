/*====================================================
 ATSC PRO v3.0
 dashboard.js
 FILE 1
 Inisialisasi Sistem
====================================================*/

//==============================
// HELPER
//==============================

function $(id) {
    return document.getElementById(id);
}

function tampilAlert(pesan) {
    alert(pesan);
}

//==============================
// FORMAT TIMER
//==============================

function formatWaktu(detik) {

    let menit = Math.floor(detik / 60);
    let sisa = detik % 60;

    if (menit < 10) menit = "0" + menit;
    if (sisa < 10) sisa = "0" + sisa;

    return menit + ":" + sisa;
}

//==============================
// CEK PERANGKAT
//==============================

function cekPerangkat(){

    DB.sekretaris.online = true;

    updateDB();

}

//==============================
// RESET DATABASE
//==============================

function resetDatabase() {

    if (!confirm("Reset seluruh database ?"))
        return;

    localStorage.removeItem("ATSC_DB");

    location.reload();

}

//==============================
// UPDATE DASHBOARD
//==============================

function updateDashboard() {

    updateStatistik();

    tampilKejuaraan();

    tampilPesilat();

    tampilPartai();

}

//====================================================
// FILE 2
// MODUL KEJUARAAN
//====================================================

//==============================
// BUKA POPUP KEJUARAAN
//==============================

function bukaKejuaraan(){

    $("popupKejuaraan").style.display = "flex";

}

//==============================
// TUTUP POPUP KEJUARAAN
//==============================

function tutupKejuaraan(){

    $("popupKejuaraan").style.display = "none";

}

//==============================
// SIMPAN KEJUARAAN
//==============================

function simpanKejuaraan(){

    const nama = $("namaKejuaraan").value.trim();
    const tempat = $("tempat").value.trim();
    const tanggal = $("tanggal").value;
    const gelanggang = parseInt($("gelanggang").value);

    if(nama==""){
        tampilAlert("Nama kejuaraan belum diisi.");
        return;
    }

    if(tempat==""){
        tampilAlert("Tempat pelaksanaan belum diisi.");
        return;
    }

    if(tanggal==""){
        tampilAlert("Tanggal belum dipilih.");
        return;
    }

    if(isNaN(gelanggang) || gelanggang<=0){
        tampilAlert("Jumlah gelanggang tidak valid.");
        return;
    }

    DB.kejuaraan = {

        nama : nama,

        tempat : tempat,

        tanggal : tanggal,

        gelanggang : gelanggang,

        dibuat : new Date().toLocaleString("id-ID")

    };

    updateDB();

    tampilKejuaraan();

    updateStatistik();

    tutupKejuaraan();

    tampilAlert("Data kejuaraan berhasil disimpan.");

}

//==============================
// TAMPILKAN KEJUARAAN
//==============================

function tampilKejuaraan(){

    const box = $("listKejuaraan");

    if(!DB.kejuaraan.nama){

        box.innerHTML = "Belum ada data kejuaraan.";

        return;

    }

    box.innerHTML = `

    <div class="card-kejuaraan">

        <h3>${DB.kejuaraan.nama}</h3>

        <p>📍 ${DB.kejuaraan.tempat}</p>

        <p>📅 ${DB.kejuaraan.tanggal}</p>

        <p>🥋 ${DB.kejuaraan.gelanggang} Gelanggang</p>

        <button class="btn-biru"
        onclick="editKejuaraan()">

            Edit

        </button>

        <button class="btn-merah"
        onclick="hapusKejuaraan()">

            Hapus

        </button>

    </div>

    `;

}

//==============================
// EDIT KEJUARAAN
//==============================

function editKejuaraan(){

    if(!DB.kejuaraan.nama){

        tampilAlert("Belum ada data.");

        return;

    }

    $("namaKejuaraan").value = DB.kejuaraan.nama;

    $("tempat").value = DB.kejuaraan.tempat;

    $("tanggal").value = DB.kejuaraan.tanggal;

    $("gelanggang").value = DB.kejuaraan.gelanggang;

    bukaKejuaraan();

}

//==============================
// HAPUS KEJUARAAN
//==============================

function hapusKejuaraan(){

    if(!confirm("Hapus data kejuaraan?"))
        return;

    DB.kejuaraan = {};

    updateDB();

    tampilKejuaraan();

    updateStatistik();

    tampilAlert("Data kejuaraan berhasil dihapus.");

}

//====================================================
// FILE 3
// MODUL PESILAT
//====================================================

//==============================
// BUKA POPUP PESILAT
//==============================

function bukaPesilat(){

    $("popupPesilat").style.display = "flex";

}

//==============================
// TUTUP POPUP PESILAT
//==============================

function tutupPesilat(){

    $("popupPesilat").style.display = "none";

}

//==============================
// SIMPAN PESILAT
//==============================

function simpanPesilat(){

    const nama = $("namaPesilat").value.trim();
    const sudut = $("sudutPesilat").value;
    const kontingen = $("kontingenPesilat").value.trim();
    const kelas = $("kelasPesilat").value.trim();
    const jk = $("jkPesilat").value;

    if(nama==""){
        tampilAlert("Nama pesilat belum diisi.");
        return;
    }

    if(kontingen==""){
        tampilAlert("Kontingen belum diisi.");
        return;
    }

    if(kelas==""){
        tampilAlert("Kelas belum diisi.");
        return;
    }

    let editIndex = $("popupPesilat").dataset.edit;

    let dataPesilat = {

        id : Date.now(),

        nama : nama,

        sudut : sudut,

        kontingen : kontingen,

        kelas : kelas,

        jk : jk

    };

    if(editIndex === undefined || editIndex === ""){

        DB.pesilat.push(dataPesilat);

    }else{

        dataPesilat.id = DB.pesilat[editIndex].id;

        DB.pesilat[editIndex] = dataPesilat;

        $("popupPesilat").dataset.edit = "";

    }

    updateDB();

    tampilPesilat();

    updateStatistik();

    tutupPesilat();

    tampilAlert("Data pesilat berhasil disimpan.");

}

//==============================
// TAMPILKAN PESILAT
//==============================

function tampilPesilat(){

    const box = $("listPesilat");

    if(DB.pesilat.length==0){

        box.innerHTML = "Belum ada data pesilat.";

        return;

    }

    let html="";

    DB.pesilat.forEach(function(p,index){

        html+=`

        <div class="card-kejuaraan">

            <h3>${p.nama}</h3>

            <p>Kontingen : ${p.kontingen}</p>

            <p>Kelas : ${p.kelas}</p>

            <p>Jenis Kelamin : ${p.jk}</p>

            <button class="btn-biru"
            onclick="editPesilat(${index})">

                Edit

            </button>

            <button class="btn-merah"
            onclick="hapusPesilat(${index})">

                Hapus

            </button>

        </div>

        `;

    });

    box.innerHTML = html;

}

//==============================
// EDIT PESILAT
//==============================

function editPesilat(index){

    let p = DB.pesilat[index];

    $("namaPesilat").value = p.nama;

    $("sudutPesilat").value = p.sudut;

    $("kontingenPesilat").value = p.kontingen;

    $("kelasPesilat").value = p.kelas;

    $("jkPesilat").value = p.jk;

    $("popupPesilat").dataset.edit = index;

    bukaPesilat();

}

//==============================
// HAPUS PESILAT
//==============================

function hapusPesilat(index){

    if(!confirm("Hapus data pesilat?"))
        return;

    DB.pesilat.splice(index,1);

    updateDB();

    tampilPesilat();

    updateStatistik();

}

//==============================
// CARI PESILAT
//==============================

function cariPesilat(keyword){

    keyword = keyword.toLowerCase();

    return DB.pesilat.filter(function(p){

        return p.nama.toLowerCase().includes(keyword) ||

               p.kontingen.toLowerCase().includes(keyword) ||

               p.kelas.toLowerCase().includes(keyword);

    });

}

//====================================================
// FILE 4.1
// MODUL PARTAI
// BUKA - TUTUP - ISI PESILAT
//====================================================

//==============================
// BUKA POPUP PARTAI
//==============================

function bukaPartai(){

    isiPesilat();

    $("nomorPartai").value = "";
    $("gelanggangPartai").value = "";
    $("kelasPartai").value = "";

    $("popupPartai").dataset.edit = "";

    $("popupPartai").style.display = "flex";

}

//==============================
// TUTUP POPUP PARTAI
//==============================

function tutupPartai(){

    $("popupPartai").style.display = "none";

}

//==============================
// ISI DATA PESILAT
//==============================

function isiPesilat(){

    const kuning = $("sudutKuning");
    const biru = $("sudutBiru");

    kuning.innerHTML =
    '<option value="">Pilih Sudut Kuning</option>';

    biru.innerHTML =
    '<option value="">Pilih Sudut Biru</option>';

    if(DB.pesilat.length==0){

        return;

    }

    DB.pesilat.forEach(function(p,index){

        const text =
        p.nama+
        " | "+
        p.kontingen+
        " | "+
        p.kelas;

        kuning.innerHTML +=
        `<option value="${index}">
            ${text}
        </option>`;

        biru.innerHTML +=
        `<option value="${index}">
            ${text}
        </option>`;

    });

}

//==============================
// SIMPAN PARTAI
//==============================

function simpanPartai(){

    const nomor = parseInt($("nomorPartai").value);
    const gelanggang = parseInt($("gelanggangPartai").value);
    const kelas = $("kelasPartai").value.trim();

    const indexKuning = $("sudutKuning").value;
    const indexBiru = $("sudutBiru").value;

    if(isNaN(nomor)){
        tampilAlert("Nomor partai belum diisi.");
        return;
    }

    if(isNaN(gelanggang)){
        tampilAlert("Nomor gelanggang belum diisi.");
        return;
    }

    if(kelas==""){
        tampilAlert("Kelas belum diisi.");
        return;
    }

    if(indexKuning==""){
        tampilAlert("Sudut Kuning belum dipilih.");
        return;
    }

    if(indexBiru==""){
        tampilAlert("Sudut Biru belum dipilih.");
        return;
    }

    if(indexKuning==indexBiru){
        tampilAlert("Pesilat Kuning dan Biru tidak boleh sama.");
        return;
    }

    const pesilatKuning = DB.pesilat[indexKuning];
    const pesilatBiru = DB.pesilat[indexBiru];

    const editIndex = $("popupPartai").dataset.edit;

    const partai = {

        id: Date.now(),

        nomor: nomor,

        gelanggang: gelanggang,

        kelas: kelas,

        kuning: {
            id: pesilatKuning.id,
            nama: pesilatKuning.nama,
            kontingen: pesilatKuning.kontingen,
            kelas: pesilatKuning.kelas
        },

        biru: {
            id: pesilatBiru.id,
            nama: pesilatBiru.nama,
            kontingen: pesilatBiru.kontingen,
            kelas: pesilatBiru.kelas
        },

        status: "BELUM AKTIF",

        ronde: 1,

        rondeTambahan: false,

        pemenangRonde: [
            "",
            "",
            ""
        ],

        pemenang: "",

        selesai: false

    };

    if(editIndex === ""){

        DB.partai.push(partai);

    }else{

        partai.id = DB.partai[editIndex].id;

        DB.partai[editIndex] = partai;

        $("popupPartai").dataset.edit = "";

    }

    updateDB();

    tampilPartai();

    updateStatistik();

    tutupPartai();

    tampilAlert("Partai berhasil disimpan.");

}

//==============================
// TAMPILKAN PARTAI
//==============================

function tampilPartai(){

    const box = $("listPartai");

    if(DB.partai.length === 0){

        box.innerHTML = "Belum ada partai.";

        return;

    }

    let html = "";

    DB.partai.forEach(function(p,index){

        let warnaStatus = "#777";

        if(p.status === "AKTIF"){
            warnaStatus = "#16a34a";
        }

        if(p.status === "SELESAI"){
            warnaStatus = "#2563eb";
        }

        html += `

        <div class="card-kejuaraan">

            <h3>
                Partai ${p.nomor}
            </h3>

            <p>
                <b>Gelanggang :</b>
                ${p.gelanggang}
            </p>

            <p>
                <b>Kelas :</b>
                ${p.kelas}
            </p>

            <hr>

            <p>
                🟡
                <b>${p.kuning.nama}</b>
            </p>

            <p>
                ${p.kuning.kontingen}
            </p>

            <br>

            <p>
                🔵
                <b>${p.biru.nama}</b>
            </p>

            <p>
                ${p.biru.kontingen}
            </p>

            <hr>

            <p>

                <b>Status :</b>

                <span style="color:${warnaStatus};font-weight:bold;">

                    ${p.status}

                </span>

            </p>

            <div class="popup-button">

                <button class="btn-biru"

                    onclick="aktifkanPartai(${index})">

                    Aktifkan

                </button>

                <button class="btn-kuning"

                    onclick="editPartai(${index})">

                    Edit

                </button>

                <button class="btn-merah"

                    onclick="hapusPartai(${index})">

                    Hapus

                </button>

            </div>

        </div>

        `;

    });

    box.innerHTML = html;

}

//====================================================
// FILE 4.4
// EDIT - HAPUS - AKTIFKAN PARTAI
//====================================================

//==============================
// EDIT PARTAI
//==============================

function editPartai(index){

    let p = DB.partai[index];

    $("nomorPartai").value = p.nomor;

    $("gelanggangPartai").value = p.gelanggang;

    $("kelasPartai").value = p.kelas;

    isiPesilat();

    // Cari index pesilat berdasarkan ID
    let indexKuning = DB.pesilat.findIndex(x => x.id === p.kuning.id);
    let indexBiru   = DB.pesilat.findIndex(x => x.id === p.biru.id);

    $("sudutKuning").value = indexKuning;
    $("sudutBiru").value = indexBiru;

    $("popupPartai").dataset.edit = index;

    bukaPartai();

}

//==============================
// HAPUS PARTAI
//==============================

function hapusPartai(index){

    if(!confirm("Hapus partai ini?"))
        return;

    DB.partai.splice(index,1);

    updateDB();

    tampilPartai();

    updateStatistik();

    tampilAlert("Partai berhasil dihapus.");

}

//==============================
// AKTIFKAN PARTAI
//==============================

function aktifkanPartai(index){

    if(!confirm("Aktifkan partai ini?"))
        return;

    // Nonaktifkan semua partai
    DB.partai.forEach(function(p){

        p.status = "BELUM AKTIF";

    });

    // Aktifkan partai terpilih
    DB.partai[index].status = "AKTIF";

    // Jadikan partai aktif
    DB.partaiAktif = structuredClone(DB.partai[index]);

    // Reset pertandingan
    DB.pertandingan = {

        ronde:1,

        status:"SIAP",

        timer:120,

        mulai:false,

        selesai:false,

        tambahan:false

    };

    // Reset nilai
    DB.nilai = {

        kuning:0,

        biru:0,

        hukumanKuning:0,

        hukumanBiru:0,

        pw1:null,

        pw2:null,

        pw3:null,

        pw4:null

    };

    updateDB();

    tampilPartai();

    updateStatistik();

    tampilAlert("Partai berhasil diaktifkan.");

    // Jika halaman KP terbuka maka refresh otomatis
    if(window.BroadcastChannel){

        const channel = new BroadcastChannel("ATSC_PRO");

        channel.postMessage({

            type:"PARTAI_AKTIF"

        });

        channel.close();

    }

}

//====================================================
// FILE 5
// IMPORT JADWAL EXCEL
//====================================================

//==============================
// BUKA FILE EXCEL
//==============================

function importExcel(){

    $("fileExcel").click();

}

//==============================
// BACA FILE EXCEL
//==============================

function bacaExcel(event){

    const file = event.target.files[0];

    if(!file){

        tampilAlert("Pilih file Excel terlebih dahulu.");

        return;

    }

    const reader = new FileReader();

    reader.onload = function(e){

        const data = new Uint8Array(e.target.result);

        const workbook = XLSX.read(data,{
            type:"array"
        });

        const sheet =
        workbook.Sheets[workbook.SheetNames[0]];

        const rows =
        XLSX.utils.sheet_to_json(sheet,{
            header:1
        });

        simpanImport(rows);

    };

    reader.readAsArrayBuffer(file);

}

//==============================
// SIMPAN HASIL IMPORT
//==============================

function simpanImport(rows){

    if(rows.length<=1){

        tampilAlert("File Excel kosong.");

        return;

    }

    let jumlahImport = 0;

    for(let i=1;i<rows.length;i++){

        let r = rows[i];

        if(r.length<6)
            continue;

        let partai = {

            id: Date.now()+i,

            nomor:r[0],

            gelanggang:r[1],

            kelas:r[2],

            kuning:{
                id:null,
                nama:r[3],
                kontingen:r[4]
            },

            biru:{
                id:null,
                nama:r[5],
                kontingen:r[6] || ""
            },

            status:"BELUM AKTIF",

            ronde:1,

            rondeTambahan:false,

            pemenangRonde:[
                "",
                "",
                ""
            ],

            pemenang:"",

            selesai:false

        };

        DB.partai.push(partai);

        jumlahImport++;

    }

    updateDB();

    tampilPartai();

    updateStatistik();

    tampilAlert(

        jumlahImport+

        " partai berhasil diimport."

    );

}

//====================================================
// UPDATE STATISTIK
//====================================================

function updateStatistik(){

    let pesilat = document.querySelector(".stat-card:nth-child(1) .stat-value");
    let partai = document.querySelector(".stat-card:nth-child(2) .stat-value");
    let gelanggang = document.querySelector(".stat-card:nth-child(3) .stat-value");
    let kejuaraan = document.querySelector(".stat-card:nth-child(4) .stat-value");

    if(pesilat) pesilat.innerHTML = DB.pesilat.length;

    if(partai) partai.innerHTML = DB.partai.length;

    if(gelanggang)
        gelanggang.innerHTML = DB.kejuaraan.gelanggang || 0;

    if(kejuaraan)
        kejuaraan.innerHTML =
            DB.kejuaraan.nama ? 1 : 0;

}

window.onload = function(){

    cekPerangkat();

    tampilKejuaraan();

    tampilPesilat();

    tampilPartai();

    updateStatistik();

}