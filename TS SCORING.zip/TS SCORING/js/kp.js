 /*====================================================
 ATSC PRO v3.0
 kp.js
 FILE KP-1
 Inisialisasi Ketua Pertandingan
====================================================*/

//==============================
// HELPER
//==============================

function $(id){
    return document.getElementById(id);
}

function tampilAlert(pesan){
    alert(pesan);
}

//==============================
// CEK KETUA PERTANDINGAN
//==============================

function cekKP(){

    DB.kp.online = true;

    updateDB();

}

//==============================
// AMBIL PARTAI AKTIF
//==============================

function ambilPartaiAktif(){

    if(!DB.partaiAktif){

        tampilAlert("Belum ada partai yang diaktifkan.");

        return;

    }

    tampilPartaiAktif();

}

//==============================
// TAMPILKAN PARTAI AKTIF
//==============================

function tampilPartaiAktif(){

    if(!DB.partaiAktif)
        return;

    let p = DB.partaiAktif;

    if($("namaKuning"))
        $("namaKuning").innerHTML = p.kuning.nama;

    if($("kontingenKuning"))
        $("kontingenKuning").innerHTML = p.kuning.kontingen;

    if($("namaBiru"))
        $("namaBiru").innerHTML = p.biru.nama;

    if($("kontingenBiru"))
        $("kontingenBiru").innerHTML = p.biru.kontingen;

    if($("kelas"))
        $("kelas").innerHTML = p.kelas;

    if($("nomorPartai"))
        $("nomorPartai").innerHTML = p.nomor;

    if($("ronde"))
        $("ronde").innerHTML = DB.pertandingan.ronde;

    updateTimer();

}

//==============================
// UPDATE TIMER
//==============================

function updateTimer(){

    if(!$("timer"))
        return;

    let detik = DB.pertandingan.timer;

    let menit = Math.floor(detik/60);
    let sisa = detik%60;

    if(menit<10) menit="0"+menit;
    if(sisa<10) sisa="0"+sisa;

    $("timer").innerHTML = menit+":"+sisa;

}

//==============================
// STATUS PERTANDINGAN
//==============================

function updateStatus(){

    if($("statusPertandingan")){

        $("statusPertandingan").innerHTML =
        DB.pertandingan.status;

    }

}

//==============================
// LOAD HALAMAN
//==============================

window.onload=function(){

    cekKP();

    ambilPartaiAktif();

    updateStatus();

}

//====================================================
// KP-2
// TIMER PERTANDINGAN
//====================================================

let intervalTimer = null;

//==============================
// MULAI TIMER
//==============================

function mulaiTimer(){

    if(intervalTimer!=null)
        return;

    DB.pertandingan.status="RONDE "+DB.pertandingan.ronde;

    updateStatus();

    updateDB();

    intervalTimer=setInterval(function(){

        if(DB.pertandingan.timer>0){

            DB.pertandingan.timer--;

            updateTimer();

          sinkronKP();

            updateDB();

        }else{

            stopTimer();

            tampilAlert("Waktu ronde habis.");

        }

    },1000);

}

//==============================
// PAUSE TIMER
//==============================

function pauseTimer(){

    clearInterval(intervalTimer);

    intervalTimer=null;

    DB.pertandingan.status="PAUSE";

    updateStatus();
  
sinkronKP();
  
    updateDB();

}

//==============================
// STOP TIMER
//==============================

function stopTimer(){

    clearInterval(intervalTimer);

    intervalTimer=null;

    DB.pertandingan.status="STOP";

    DB.pertandingan.timer=120;

    updateTimer();

    updateStatus();

  sinkronKP();

    updateDB();

}

//====================================================
// KP-3
// MANAJEMEN RONDE
//====================================================

//==============================
// SELESAI RONDE
//==============================

function selesaiRonde(){

    pauseTimer();

    if(DB.pertandingan.ronde==1){

        DB.pertandingan.ronde=2;

        DB.pertandingan.timer=120;

        DB.pertandingan.status="RONDE 2";

    }

    else if(DB.pertandingan.ronde==2){

        if(DB.pertandingan.rondeTambahan){

            DB.pertandingan.ronde=3;

            DB.pertandingan.timer=120;

            DB.pertandingan.status="RONDE TAMBAHAN";

        }

        else{

            DB.pertandingan.status="SELESAI";

        }

    }

    else{

        DB.pertandingan.status="SELESAI";

    }

    updateTimer();

    updateStatus();

  sinkronKP();

    if($("ronde")){

        $("ronde").innerHTML=DB.pertandingan.ronde;

    }

    updateDB();

}

//==============================
// RESET TIMER RONDE
//==============================

function resetTimerRonde(){

    DB.pertandingan.timer=120;

    updateTimer();

    updateDB();

}

//====================================================
// KP-4
// KEPUTUSAN PERTANDINGAN
//====================================================

//==============================
// MENANG ANGKA
//==============================

function menangAngka(sudut){

    DB.pertandingan.status = "SELESAI";
    DB.pertandingan.pemenangAkhir = sudut;
    DB.pertandingan.alasan = "MENANG ANGKA";

    updateStatus();
    updateDB();

  sinkronKP();
    tampilAlert("Pemenang : " + sudut.toUpperCase() + " (MENANG ANGKA)");

}

//==============================
// MENANG TEKNIK
//==============================

function menangTeknik(sudut){

    DB.pertandingan.status = "SELESAI";
    DB.pertandingan.pemenangAkhir = sudut;
    DB.pertandingan.alasan = "MENANG TEKNIK";

    updateStatus();
    updateDB();

  sinkronKP();
    tampilAlert("Pemenang : " + sudut.toUpperCase() + " (MENANG TEKNIK)");

}

//==============================
// WMP
//==============================

function menangWMP(sudut){

    DB.pertandingan.status = "SELESAI";
    DB.pertandingan.pemenangAkhir = sudut;
    DB.pertandingan.alasan = "WMP";

    updateStatus();
    updateDB();

  sinkronKP();
    tampilAlert("Pemenang : " + sudut.toUpperCase() + " (WMP)");

}

//==============================
// DISKUALIFIKASI
//==============================

function diskualifikasi(){

    let sudut = prompt("Diskualifikasi sudut (kuning/biru)");

    if(!sudut)
        return;

    sudut = sudut.toLowerCase();

    DB.pertandingan.status = "SELESAI";

    if(sudut=="kuning")
        DB.pertandingan.pemenangAkhir="biru";
    else
        DB.pertandingan.pemenangAkhir="kuning";

    DB.pertandingan.alasan="DISKUALIFIKASI";

    updateStatus();
    updateDB();

  sinkronKP();
    tampilAlert("Pertandingan selesai karena Diskualifikasi.");

}

//==============================
// WALK OVER
//==============================

function walkOver(sudut){

    DB.pertandingan.status="SELESAI";
    DB.pertandingan.pemenangAkhir=sudut;
    DB.pertandingan.alasan="WO";

    updateStatus();
    updateDB();

  sinkronKP();

    tampilAlert("Pemenang : "+sudut.toUpperCase()+" (WO)");

}

//==============================
// RESET PERTANDINGAN
//==============================

function resetPertandingan(){

    if(!confirm("Reset pertandingan?"))
        return;

    DB.pertandingan.ronde = 1;
    DB.pertandingan.timer = 120;
    DB.pertandingan.status = "SIAP";

    DB.pertandingan.score.kuning = 0;
    DB.pertandingan.score.biru = 0;

    DB.pertandingan.hukuman.kuning = 0;
    DB.pertandingan.hukuman.biru = 0;

    DB.pertandingan.pemenangRonde1 = "";
    DB.pertandingan.pemenangRonde2 = "";
    DB.pertandingan.pemenangTambahan = "";
    DB.pertandingan.pemenangAkhir = "";
    DB.pertandingan.alasan = "";

    updateTimer();
    updateStatus();

    if($("ronde"))
        $("ronde").innerHTML = 1;

    if($("scoreKuning"))
        $("scoreKuning").innerHTML = 0;

    if($("scoreBiru"))
        $("scoreBiru").innerHTML = 0;

    updateDB();

  sinkronKP();

    tampilAlert("Pertandingan berhasil direset.");

}

//====================================================
// KP-5
// SINKRONISASI DATA
//====================================================

//==============================
// KIRIM UPDATE KE DATABASE
//==============================

function sinkronKP(){

    updateDB();

}

//==============================
// UPDATE SCORE KP
//==============================

function updateScoreKP(){

    if($("scoreKuning"))
        $("scoreKuning").innerHTML =
        DB.pertandingan.score.kuning;

    if($("scoreBiru"))
        $("scoreBiru").innerHTML =
        DB.pertandingan.score.biru;

    sinkronKP();

}

//==============================
// UPDATE TIMER
//==============================

function updateTimerKP(){

    updateTimer();

    sinkronKP();

}

//==============================
// UPDATE STATUS
//==============================

function updateStatusKP(){

    updateStatus();

    sinkronKP();

}

//==============================
// AUTO REFRESH DATABASE
//==============================

setInterval(function(){

    let dbBaru = loadDB();

    DB = dbBaru;

    updateScoreKP();

    updateTimer();

    updateStatus();

},500);