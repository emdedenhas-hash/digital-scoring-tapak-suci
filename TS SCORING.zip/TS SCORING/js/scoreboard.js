function tampilScoreboard(){

let data =
JSON.parse(localStorage.getItem("partaiAktif"));

if(!data) return;

document.getElementById("namaKuning").innerHTML=data.kuning;

document.getElementById("namaBiru").innerHTML=data.biru;

document.getElementById("status").innerHTML=data.status;

}

window.onload=tampilScoreboard;