/* =====================================================
   ATSC PRO v3.1
   PW.JS
   BAGIAN 1
   Inisialisasi
===================================================== */

// ================= DATABASE =================

DB = loadDB();

// ================= IDENTITAS PW =================

// Ubah sesuai perangkat:
// PW1, PW2, PW3 atau PW4

const PW_ID = "pw1";

// ================= DATA RONDE =================

let rondeAktif = 1;

let historyRonde = [];

// ================= INIT =================

function initPW(){

    DB = loadDB();

    if(!DB.pw){

        DB.pw = {};

    }

    if(!DB.pw[PW_ID]){

        DB.pw[PW_ID]={

            online:false,

            history:[]

        };

    }

    DB.pw[PW_ID].online=true;

    updateDB();

}

// ================= LOAD PARTAI =================

function loadPartaiAktif(){

    DB = loadDB();

    if(DB.partaiAktif===null){

        return;

    }

    const partai=DB.partai[DB.partaiAktif];

    if(!partai){

        return;

    }

    document.getElementById("nomorPartai").innerHTML=partai.nomor || "-";

    document.getElementById("kelasPartai").innerHTML=partai.kelas || "-";

    document.getElementById("namaKuning").innerHTML=partai.kuning || "-";

    document.getElementById("namaBiru").innerHTML=partai.biru || "-";

    document.getElementById("kontingenKuning").innerHTML=partai.kontingenKuning || "-";

    document.getElementById("kontingenBiru").innerHTML=partai.kontingenBiru || "-";

    document.getElementById("gelanggang").innerHTML=DB.kejuaraan.gelanggang;

}

// ================= LOAD RONDE =================

function loadRondeAktif(){

    DB=loadDB();

    rondeAktif=DB.pertandingan.ronde;

    document.getElementById("ronde").innerHTML=rondeAktif;

}

// ================= UPDATE SCORE =================

function tampilScore(){

    DB=loadDB();

    const ronde=getNamaRonde();

    document.getElementById("scoreKuning").innerHTML=
        DB.pertandingan.score[ronde][PW_ID].kuning;

    document.getElementById("scoreBiru").innerHTML=
        DB.pertandingan.score[ronde][PW_ID].biru;

}

// ================= LOAD HISTORY =================

function loadHistory(){

    DB=loadDB();

    historyRonde=

    DB.pw[PW_ID].history || [];

}

// ================= AUTO =================

window.onload=function(){

    initPW();

    loadPartaiAktif();

    loadRondeAktif();

    tampilScore();

    loadHistory();

};

/* =====================================================
   PW.JS
   BAGIAN 2
   INPUT NILAI TAPAK SUCI
===================================================== */

// ================= NAMA RONDE =================

function getNamaRonde() {

    switch (DB.pertandingan.ronde) {

        case 1:
            return "ronde1";

        case 2:
            return "ronde2";

        default:
            return "rondeTambahan";
    }

}

// ================= INPUT NILAI =================

function inputNilai(sudut, jenis, nilai) {

    DB = loadDB();

    const ronde = getNamaRonde();

    // Tambahkan nilai sesuai ronde aktif
    DB.pertandingan.score[ronde][PW_ID][sudut]+=nilai;

    // Simpan riwayat PW
    if (!DB.pw[PW_ID].history[ronde]) {

        DB.pw[PW_ID].history[ronde] = [];

    }

    DB.pw[PW_ID].history[ronde].push({

        waktu: new Date().toLocaleTimeString(),

        jenis: jenis,

        sudut: sudut,

        nilai: nilai

    });

    updateDB();

    tampilScore();

    tampilHistory();

}

// ================= TAMPILKAN SCORE =================

function tampilScore(){

    DB=loadDB();

    const ronde=getNamaRonde();

    document.getElementById("scoreKuning").innerHTML=

        DB.pertandingan.score[ronde][PW_ID].kuning;

    document.getElementById("scoreBiru").innerHTML=

        DB.pertandingan.score[ronde][PW_ID].biru;

}

// ================= TAMPILKAN RIWAYAT =================

function tampilHistory() {

    DB = loadDB();

    const ronde = getNamaRonde();

    const list = document.getElementById("historyList");

    list.innerHTML = "";

    let history = DB.pw[PW_ID].history[ronde];

    if (!history || history.length === 0) {

        list.innerHTML =
        "<div class='history-empty'>Belum ada penilaian.</div>";

        return;

    }

    history.forEach((item, index) => {

        list.innerHTML += `

        <div class="history-item">

            <div>

                ${item.waktu}

                |

                ${item.sudut.toUpperCase()}

                |

                ${item.jenis}

                |

                ${item.nilai > 0 ? "+" : ""}${item.nilai}

            </div>

            <button
            onclick="hapusHistory(${index})">

                ❌

            </button>

        </div>

        `;

    });

}

/* =====================================================
   PW.JS
   BAGIAN 3
   INPUT HUKUMAN TAPAK SUCI
===================================================== */

// ================= INPUT HUKUMAN =================

function inputHukuman(sudut, jenis, nilai){

    // Konfirmasi khusus Diskualifikasi
    if(jenis==="diskualifikasi"){

        if(!confirm(
            "Yakin memberikan DISKUALIFIKASI kepada sudut "
            + sudut.toUpperCase() + " ?"
        )){
            return;
        }

    }

    DB = loadDB();

    const ronde = getNamaRonde();

    // Tambahkan hukuman
    DB.pertandingan.hukuman[ronde][PW_ID][sudut] += nilai;

    // Kurangi skor ronde aktif
    DB.pertandingan.score[ronde][PW_ID][sudut] += nilai;

    // Simpan riwayat
    DB.pw[PW_ID].history[ronde].push({

        waktu : new Date().toLocaleTimeString(),

        jenis : jenis,

        sudut : sudut,

        nilai : nilai,

        tipe : "hukuman"

    });

    updateDB();

    tampilScore();

    tampilHistory();

}

// ================= HAPUS SATU RIWAYAT =================

function hapusHistory(index){

    DB = loadDB();

    const ronde = getNamaRonde();

    let item = DB.pw[PW_ID].history[ronde][index];

    if(!item) return;

    if(!confirm("Batalkan input ini?")) return;

    // Kembalikan skor
    DB.pertandingan.score[ronde][PW_ID][item.sudut] -= item.nilai;

    // Jika hukuman, kembalikan hukuman juga
    if(item.tipe==="hukuman"){

        DB.pertandingan.hukuman[ronde][PW_ID][item.sudut] -= item.nilai;

    }

    DB.pw[PW_ID].history[ronde].splice(index,1);

    updateDB();

    tampilScore();

    tampilHistory();

}

// ================= HAPUS TERAKHIR =================

function hapusInputTerakhir(){

    DB = loadDB();

    const ronde = getNamaRonde();

    let history = DB.pw[PW_ID].history[ronde];

    if(history.length===0) return;

    hapusHistory(history.length-1);

}

// ================= BERSIHKAN RIWAYAT =================

function bersihkanRiwayat(){

    if(!confirm("Hapus seluruh riwayat ronde ini?")){

        return;

    }

    DB = loadDB();

    const ronde = getNamaRonde();

    DB.pw[PW_ID].history[ronde] = [];

    DB.pertandingan.score[ronde][PW_ID] = {

        kuning:0,

        biru:0

    };

    DB.pertandingan.hukuman[ronde][PW_ID] = {

        kuning:0,

        biru:0

    };

    updateDB();

    tampilScore();

    tampilHistory();

}

/* =====================================================
   PW.JS
   BAGIAN 4
   SINKRONISASI REAL-TIME
===================================================== */

// ================= AUTO SYNC =================

let lastSync = "";

function startAutoSync(){

    // Sinkron setiap 500 ms
    setInterval(syncDatabase,500);

}

// ================= SYNC DATABASE =================

function syncDatabase(){

    DB = loadDB();

    // Jika ronde berubah dari KP
    if(rondeAktif !== DB.pertandingan.ronde){

        rondeAktif = DB.pertandingan.ronde;

        tampilScore();

        tampilHistory();

    }

    // Jika timer berubah
    const timer = document.getElementById("timer");

    if(timer){

        timer.innerHTML = formatTimer(DB.pertandingan.timer);

    }

    // Jika status berubah
    const status = document.getElementById("statusPertandingan");

    if(status){

        status.innerHTML = DB.pertandingan.status;

    }

    // Refresh nilai
    tampilScore();

}

// ================= FORMAT TIMER =================

function formatTimer(detik){

    let menit = Math.floor(detik / 60);

    let sisa = detik % 60;

    if(menit < 10){

        menit = "0" + menit;

    }

    if(sisa < 10){

        sisa = "0" + sisa;

    }

    return menit + ":" + sisa;

}

// ================= UPDATE STATUS ONLINE =================

setInterval(function(){

    DB = loadDB();

    if(DB.pw && DB.pw[PW_ID]){

        DB.pw[PW_ID].online = true;

        DB.pw[PW_ID].lastUpdate = Date.now();

        updateDB();

    }

},2000);

// ================= CEK KONEKSI =================

function cekKoneksi(){

    DB = loadDB();

    let status = document.getElementById("statusPW");

    if(!status) return;

    status.innerHTML = "🟢 ONLINE";

    status.style.color = "#00ff66";

}

setInterval(cekKoneksi,1000);

/* =====================================================
   PW.JS
   BAGIAN 5
   PERGANTIAN RONDE & REKAP
===================================================== */

// ================= SELESAIKAN RONDE =================

function selesaiRonde(){

    DB = loadDB();

    const ronde = getNamaRonde();

    // Simpan total ronde ini
    DB.pertandingan.total.kuning +=
        DB.pertandingan.score[ronde][PW_ID].kuning;

    DB.pertandingan.total.biru +=
        DB.pertandingan.score[ronde][PW_ID].biru;

    updateDB();

}

// ================= PINDAH RONDE =================

function gantiRonde(rondeBaru){

    DB = loadDB();

    DB.pertandingan.ronde = rondeBaru;

    updateDB();

    rondeAktif = rondeBaru;

    tampilScore();

    tampilHistory();

}

// ================= RESET NILAI RONDE =================

function resetNilaiRonde(){

    DB = loadDB();

    const ronde = getNamaRonde();

    DB.pertandingan.score[ronde][PW_ID] = {

        kuning:0,

        biru:0

    };

    DB.pertandingan.hukuman[ronde][PW_ID] = {

        kuning:0,

        biru:0

    };

    DB.pw[PW_ID].history[ronde] = [];

    updateDB();

    tampilScore();

    tampilHistory();

}

// ================= REKAP PW =================

function getRekapPW(){

    DB = loadDB();

    return {

        ronde1 : {

            score : DB.pertandingan.score.ronde1[PW_ID],

            hukuman : DB.pertandingan.hukuman.ronde1[PW_ID]

        },

        ronde2 : {

            score : DB.pertandingan.score.ronde2[PW_ID],

            hukuman : DB.pertandingan.hukuman.ronde2[PW_ID]

        },

        rondeTambahan : {

            score : DB.pertandingan.score.rondeTambahan[PW_ID],

            hukuman : DB.pertandingan.hukuman.rondeTambahan[PW_ID]

        }

    };

}

// ================= KIRIM KE KP =================

function kirimKeKP(){

    DB = loadDB();

    DB.kp.dataPW = DB.kp.dataPW || {};

    DB.kp.dataPW[PW_ID] = getRekapPW();

    updateDB();

}

// ================= SELESAI PERTANDINGAN =================

function selesaiPertandingan(){

    selesaiRonde();

    kirimKeKP();

    alert("Data Pembantu Wasit berhasil dikirim ke Ketua Pertandingan.");

}

/* =====================================================
   PW.JS
   BAGIAN 6 (FINAL)
   VALIDASI & KEAMANAN
===================================================== */

// ================= STATUS INPUT =================

function bolehInput(){

    DB = loadDB();

    if(DB.pertandingan.status !== "JALAN"){

        alert("Pertandingan belum berjalan.");

        return false;

    }

    return true;

}

// ================= KUNCI TOMBOL =================

function updateButtonState(){

    DB = loadDB();

    const tombol = document.querySelectorAll("button");

    tombol.forEach(btn=>{

        if(btn.classList.contains("btn-system")){

            return;

        }

        btn.disabled = DB.pertandingan.status !== "JALAN";

    });

}

// ================= AUTO REFRESH =================

setInterval(function(){

    DB = loadDB();

    tampilScore();

    tampilHistory();

    updateButtonState();

},500);

// ================= OFFLINE DETECTOR =================

setInterval(function(){

    DB = loadDB();

    let sekarang = Date.now();

    if(DB.pw && DB.pw[PW_ID]){

        if(DB.pw[PW_ID].lastUpdate){

            let selisih = sekarang - DB.pw[PW_ID].lastUpdate;

            let status = document.getElementById("statusPW");

            if(status){

                if(selisih < 4000){

                    status.innerHTML = "🟢 ONLINE";

                    status.style.color = "#00ff66";

                }else{

                    status.innerHTML = "🔴 OFFLINE";

                    status.style.color = "#ff4444";

                }

            }

        }

    }

},1000);

// ================= RESET SAAT RELOAD =================

window.addEventListener("beforeunload",function(){

    DB = loadDB();

    if(DB.pw && DB.pw[PW_ID]){

        DB.pw[PW_ID].online = false;

        updateDB();

    }

});

// ================= SELESAI =================

console.log("ATSC PRO PW MODULE LOADED");