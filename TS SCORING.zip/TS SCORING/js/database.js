// ===========================================
// ATSC PRO v3.0
// DATABASE ENGINE
// ===========================================

const DB_NAME = "ATSC_DB_V3";
const DB_VERSION = "3.1";

//===========================================
// DATABASE DEFAULT
//===========================================

const defaultDB = {

  version: DB_VERSION,
    kejuaraan: {
        nama: "",
        tempat: "",
        tanggal: "",
        gelanggang: 1
    },

    pesilat: [],

    partai: [],

    partaiAktif: null,

    pertandingan: {

    ronde: 1,

    maxRonde: 2,

    rondeTambahan: false,

    status: "STOP",

    timer: 120,

    timerBerjalan: false,

    /* ================= NILAI PER RONDE ================= */

    score: {

    ronde1: {

        pw1:{kuning:0,biru:0},

        pw2:{kuning:0,biru:0},

        pw3:{kuning:0,biru:0},

        pw4:{kuning:0,biru:0}

    },

    ronde2: {

        pw1:{kuning:0,biru:0},

        pw2:{kuning:0,biru:0},

        pw3:{kuning:0,biru:0},

        pw4:{kuning:0,biru:0}

    },

    rondeTambahan: {

        pw1:{kuning:0,biru:0},

        pw2:{kuning:0,biru:0},

        pw3:{kuning:0,biru:0},

        pw4:{kuning:0,biru:0}

    }

},

    /* ================= HUKUMAN PER RONDE ================= */

    hukuman:{

    ronde1:{

        pw1:{kuning:0,biru:0},

        pw2:{kuning:0,biru:0},

        pw3:{kuning:0,biru:0},

        pw4:{kuning:0,biru:0}

    },

    ronde2:{

        pw1:{kuning:0,biru:0},

        pw2:{kuning:0,biru:0},

        pw3:{kuning:0,biru:0},

        pw4:{kuning:0,biru:0}

    },

    rondeTambahan:{

        pw1:{kuning:0,biru:0},

        pw2:{kuning:0,biru:0},

        pw3:{kuning:0,biru:0},

        pw4:{kuning:0,biru:0}

    }

},

    /* ================= REKAP NILAI ================= */

    total: {

        kuning: 0,

        biru: 0

    },

    /* ================= PEMENANG ================= */

    pemenangRonde1: "",

    pemenangRonde2: "",

    pemenangTambahan: "",

    pemenangAkhir: ""

},

    pw: {

    pw1: {

        online:false,

        history:{

            ronde1:[],

            ronde2:[],

            rondeTambahan:[]

        }

    },

    pw2: {

        online:false,

        history:{

            ronde1:[],

            ronde2:[],

            rondeTambahan:[]

        }

    },

    pw3: {

        online:false,

        history:{

            ronde1:[],

            ronde2:[],

            rondeTambahan:[]

        }

    },

    pw4: {

        online:false,

        history:{

            ronde1:[],

            ronde2:[],

            rondeTambahan:[]

        }

    }

},

    scoreboard: {

        online: false

    },

    kp: {

        online: false

    },

    sekretaris: {

        online: false

    }

};

//===========================================
// DATABASE MIGRATION V3.1
//===========================================

function migrateDatabase(db){

    if(!db.version){

        db.version="1.0";

    }

    // ===== Upgrade ke 3.1 =====

    if(db.version!=="3.1"){

        if(!db.pertandingan){

            db.pertandingan={};

        }

        db.pertandingan.ronde ??=1;
        db.pertandingan.maxRonde ??=2;
        db.pertandingan.status ??="STOP";
        db.pertandingan.timer ??=120;
        db.pertandingan.timerBerjalan ??=false;
        db.pertandingan.rondeTambahan ??=false;

        // ================= SCORE =================

        if(!db.pertandingan.score ||
           !db.pertandingan.score.ronde1){

            db.pertandingan.score=
            JSON.parse(JSON.stringify(defaultDB.pertandingan.score));

        }

        // ================= HUKUMAN =================

        if(!db.pertandingan.hukuman ||
           !db.pertandingan.hukuman.ronde1){

            db.pertandingan.hukuman=
            JSON.parse(JSON.stringify(defaultDB.pertandingan.hukuman));

        }

        // ================= TOTAL =================

        if(!db.pertandingan.total){

            db.pertandingan.total={

                kuning:0,

                biru:0

            };

        }

        // ================= HASIL =================

        if(!db.pertandingan.hasilRonde){

            db.pertandingan.hasilRonde={

                ronde1:{kuning:0,biru:0,pemenang:""},

                ronde2:{kuning:0,biru:0,pemenang:""},

                rondeTambahan:{kuning:0,biru:0,pemenang:""}

            };

        }

        // ================= PW =================

        if(!db.pw){

            db.pw={};

        }

        ["pw1","pw2","pw3","pw4"].forEach(id=>{

            if(!db.pw[id]){

                db.pw[id]={};

            }

            db.pw[id].online ??= false;

            db.pw[id].lastUpdate ??=0;

            if(!db.pw[id].history){

                db.pw[id].history={

                    ronde1:[],

                    ronde2:[],

                    rondeTambahan:[]

                };

            }

        });

        db.version="3.1";

    }

    return db;

}

//===========================================
// LOAD DATABASE
//===========================================

function loadDB(){

    let db=localStorage.getItem(DB_NAME);

    if(db){

        db=JSON.parse(db);

        db=migrateDatabase(db);

        localStorage.setItem(DB_NAME,JSON.stringify(db));

        return db;

    }

    localStorage.setItem(

        DB_NAME,

        JSON.stringify(defaultDB)

    );

    return JSON.parse(JSON.stringify(defaultDB));

}

//===========================================
// SIMPAN DATABASE
//===========================================

function saveDB(db){

    localStorage.setItem(DB_NAME,JSON.stringify(db));

}

//===========================================
// RESET DATABASE
//===========================================

function resetDB(){

    if(confirm("Reset seluruh database?")){

        localStorage.setItem(DB_NAME,JSON.stringify(defaultDB));

        location.reload();

    }

}

//===========================================
// AMBIL DATABASE
//===========================================

let DB = loadDB();

//===========================================
// UPDATE DATABASE
//===========================================

function updateDB(){

    saveDB(DB);

}

//===========================================
// CEK DATABASE
//===========================================

function cekDB(){

    console.log(DB);
console.log("DATABASE VERSION :",DB.version);
}

console.log("DATABASE BERHASIL DIMUAT");
console.log(DB);