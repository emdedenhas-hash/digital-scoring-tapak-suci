function login(){

let role=document.getElementById("role").value;

if(role=="sekretaris"){

window.location.href="sekretaris.html";

}

else if(role=="kp"){

window.location.href="kp.html";

}

else{

window.location.href="pw.html";

}

}